
# Ride Report Tracker Power BI Automation Tool

This package upgrades the Ride Report Tracker into a professional
Automotive Validation Analytics platform.

Features:
- CSV automation
- PostgreSQL storage
- Power BI integration
- Burndown monitoring
- Upload audit logging
- Validation KPI dashboards

Recommended Stack:
- Flask Backend
- PostgreSQL/Supabase
- Microsoft Power BI
- Vercel + Render deployment

Deployment Steps:
1. Create Supabase database
2. Run database_schema.sql
3. Configure environment variables
4. Start automation_backend.py
5. Connect Power BI Desktop to PostgreSQL
