
from flask import Flask, request, jsonify
import pandas as pd
import psycopg2
from datetime import datetime
import os

app = Flask(__name__)

DB_HOST = os.getenv("DB_HOST")
DB_NAME = os.getenv("DB_NAME")
DB_USER = os.getenv("DB_USER")
DB_PASS = os.getenv("DB_PASS")

def get_connection():
    return psycopg2.connect(
        host=DB_HOST,
        database=DB_NAME,
        user=DB_USER,
        password=DB_PASS
    )

@app.route("/upload_csv", methods=["POST"])
def upload_csv():
    if "file" not in request.files:
        return jsonify({"error": "No file uploaded"}), 400

    file = request.files["file"]

    if not file.filename.endswith(".csv"):
        return jsonify({"error": "Invalid file type"}), 400

    df = pd.read_csv(file)

    required_columns = [
        "vehicle",
        "category",
        "planned_minutes",
        "achieved_minutes"
    ]

    for col in required_columns:
        if col not in df.columns:
            return jsonify({"error": f"Missing column: {col}"}), 400

    conn = get_connection()
    cur = conn.cursor()

    for _, row in df.iterrows():
        cur.execute("""
            INSERT INTO category_progress
            (vehicle, category, planned_minutes, achieved_minutes, upload_time)
            VALUES (%s, %s, %s, %s, %s)
        """, (
            row["vehicle"],
            row["category"],
            row["planned_minutes"],
            row["achieved_minutes"],
            datetime.utcnow()
        ))

    conn.commit()
    cur.close()
    conn.close()

    return jsonify({"status": "success"})

if __name__ == "__main__":
    app.run(debug=True)
