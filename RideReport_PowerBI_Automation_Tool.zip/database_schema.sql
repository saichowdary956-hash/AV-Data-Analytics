
CREATE TABLE category_progress (
    id SERIAL PRIMARY KEY,
    vehicle TEXT,
    category TEXT,
    planned_minutes INTEGER,
    achieved_minutes INTEGER,
    upload_time TIMESTAMP
);

CREATE TABLE upload_audit (
    id SERIAL PRIMARY KEY,
    csv_name TEXT,
    uploaded_at TIMESTAMP,
    records_inserted INTEGER,
    status TEXT
);
